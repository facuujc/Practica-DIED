package isi.died.tp.estructuras;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArbolBinarioBusquedaTest {

	@Test
	public void testContiene() {
		fail("Not yet implemented");
	}

	@Test
	public void testEqualsArbolOfE() {
		fail("Not yet implemented");
	}

	@Test
	public void testAgregar() {
		fail("Not yet implemented");
	}

	@Test
	public void testProfundidad() {
		fail("Not yet implemented");
	}

	@Test
	public void testCuentaNodosDeNivel() {
		fail("Not yet implemented");
	}

	@Test
	public void testEsCompleto() {
		fail("Not yet implemented");
	}

	@Test
	public void testEsLleno() {
		fail("Not yet implemented");
	}

}
