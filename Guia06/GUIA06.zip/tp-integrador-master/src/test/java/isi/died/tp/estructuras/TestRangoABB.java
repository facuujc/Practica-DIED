package isi.died.tp.estructuras;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestRangoABB {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
