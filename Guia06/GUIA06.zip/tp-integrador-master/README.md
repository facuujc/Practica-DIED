# tp-integrador

##Resolver problema de maven
C:\Users\st\tmp\tp-integrador>set MAVEN_OPTS=-Dhttp.proxyHost=proxy.frsf.utn.edu
.ar -Dhttp.proxyPort=8080 -Dhttps.proxyHost=proxy.frsf.utn.edu.ar -Dhttps.proxyP
ort=8080
